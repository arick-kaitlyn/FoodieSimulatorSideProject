package com.FoodieSimulator.side.project.dao;

public interface CuisineDAO {
}
