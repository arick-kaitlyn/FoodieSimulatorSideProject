# Foodie-Simulator-Project

Implement database Sql -- foodiesimulatorproject.sql

Member has the following attributes:
- Member Id
- First Name
- Last Name
- Email Address
  
Restaurant has the following attributes:
- Restaurant Id
- Name
- Address 1
- Address 2
- City
- State
- Cuisine type

Rating has the following attributes:
- Rating Id
- Thumbs up
- Thumbs down

Cusine has the following attributes:
- Cuisine Id
- Name
(Each Name must be unique)


